
public class ArrayFun {
	public static void main(String[] args) {
		
		int x = 0;
				
		while (x < 100) {
			System.out.println(x);
			x = x + 3;
		}
	}
}
